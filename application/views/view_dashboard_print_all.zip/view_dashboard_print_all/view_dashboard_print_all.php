<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Alsmani</title>

        <style type="text/css">

            #container{
                margin-top: 5%
            }
            table {
                table-layout: fixed;
                width:100%;
                border-collapse: collapse;
            }
            td{
                padding:8px;
            }
            #left {
                float: left;
                text-align: left;
                padding-right: 10px;
            }
            #right {
                float: right;
                text-align: right;
                padding-left: 10px;
            }
        </style>
    </head>
    <body onload="window.print()">
        <div id="container">
            <h1 style="text-align:center">Alsmani</h1>
            <h4 style="text-align:left">All Information </h4>
            <table border="1">

                <?php
                foreach ($print_data as $row):
                    $ok_spon_name = $row->okala_sponsor_name;
                    $ok_office = $row->okala_office;
                    $ok_status = $row->okala_status;
                    $ok_note = $row->okala_note;

                    $name = $row->name;
                    $passport_number = $row->passport_no;
                    $id_no = $row->basic_id_number;
                    $visa_no = $row->basic_visa_number;
                    $fingering = $row->basic_fingering;
                    $reference_name = $row->reference_name;
                    $reference_mobile_number = $row->reference_mobile_number;
                    $broker_name = $row->broker_name;
                    $broker_mobile_number = $row->broker_mobile_number;
                    $sponsor_name = $row->okala_sponsor_name;
                    $gender = $row->basic_passport_type;
                    $passport_side = $row->basic_receive_site;
                    $basic_flight = $row->basic_flight;
                    $basic_note = $row->basic_note;
                    
                    
                    $enjaz_mufa_number = $row->enzaz_mufa_number;
                    $enjaz_date = $row->enzaz_date;
                    $enjaz_note = $row->enzaz_note;
                    
                    $embassy_status = $row->embassy_visa_stamping_status;
                    $embassy_date = $row->embassy_date;
                    $embassy_expire_date = $row->embasy_expire_date;
                    $embassy_office = $row->embasy_office;
                    $embassy_note = $row->embassy_note;
                    
                    $fitcard_receive_date = $row->fit_receive_receive_date;
                    $fitcard_expire_date = $row->fit_receive_expire_date;
                    $fitcard_note = $row->fit_receive_note;

                endforeach;
                ?>
                
                <tr>                
                    <td >Okala Sponsor Name</td>
                    <td ><?= $ok_spon_name ?></td> 				  
                </tr>
                <tr>
                    <td >Okala Office</td>
                    <td ><?= $ok_office ?></td>

                </tr>
                <tr>
                    <td>Okala Status</td>
                    <td ><?= $ok_status?></td>                   
                </tr>
                <tr>
                    <td>Okala Note</td>
                    <td ><?= $ok_note ?></td>                   
                </tr>
                <tr>
                    <td>Name</td>
                    <td ><?= $name ?></td>                   
                </tr>
                <tr>
                    <td>Passport Number </td>
                    <td ><?= $passport_number ?></td>                   
                </tr>
                <tr>
                    <td>ID NO</td>
                    <td ><?= $id_no ?></td>                   
                </tr>
                <tr>
                    <td>VISA NO</td>
                    <td ><?= $visa_no ?></td>                   
                </tr>
                <tr>
                    <td>Fingering</td>
                    <td ><?= $fingering ?></td>                   
                </tr>
                <tr>
                    <td>Reference Name</td>
                    <td ><?= $reference_name?></td>                   
                </tr>
                <tr>
                    <td>Reference Mobile Number</td>
                    <td ><?= $reference_mobile_number ?></td>                   
                </tr>
                <tr>
                    <td>BROKER NAME</td>
                    <td ><?= $broker_name ?></td>                   
                </tr>


                <tr>
                    <td>BROKER Mobile Number</td>
                    <td ><?= $broker_mobile_number ?></td>                   
                </tr>
                <tr>
                    <td>Sponsor Name</td>
                    <td ><?= $sponsor_name ?></td>                   
                </tr>
                <tr>
                    <td>Gender</td>
                    <td ><?= $gender ?></td>                   
                </tr>
                <tr>
                    <td>Passport Side</td>
                    <td ><?= $passport_side ?></td>                   
                </tr>
                <tr>
                    <td>Basic Flight</td>
                    <td ><?= $basic_flight ?></td>                   
                </tr>
                <tr>
                    <td>Note</td>
                    <td ><?= $basic_note ?></td>                   
                </tr>
                <tr>
                    <td>Enjaz Mufa Number</td>
                    <td ><?= $enjaz_mufa_number ?></td>                   
                </tr>
                <tr>
                    <td>Enjaz Date</td>
                    <td ><?= $enjaz_date ?></td>                   
                </tr>
                <tr>
                    <td>Enjaz Note </td>
                    <td ><?= $enjaz_note ?></td>                   
                </tr>
                
                <tr>
                    <td>Embassy Status*</td>
                    <td ><?= $embassy_status?></td>                   
                </tr>
                <tr>
                    <td>Embassy Date</td>
                    <td ><?= $embassy_date ?></td>                   
                </tr>
                 <tr>
                    <td>Embassy Expire Date</td>
                    <td ><?= $embassy_expire_date ?></td>                   
                </tr>
                <tr>
                    <td>Embassy Office</td>
                    <td ><?= $embassy_office ?></td>                   
                </tr>
                <tr>
                    <td>Embassy Note</td>
                    <td ><?= $embassy_note ?></td>                   
                </tr>
                <tr>
                    <td>Fitcard Receive Date</td>
                    <td ><?= $fitcard_receive_date ?></td>                   
                </tr>
                <tr>
                    <td>Fitcard Expire Date</td>
                    <td ><?= $fitcard_expire_date ?></td>                   
                </tr>
                
                <tr>
                    <td>Fitcard Note</td>
                    <td ><?= $fitcard_note?></td>                   
                </tr>

            </table>

        </div>
        <br><br><br><div id="left"><u>Approval Signature</u></div>
        <div id="right"><u>Receiver Signature</u></div>





    </body>
</html>