
<script>


    function addModal(id) {


        $("#reference_name").val(id);
        $("#addModal").modal();
    }
    function deleteModal(id) {
        $("#delete_id").val(id);
        $("#myModalDelete").modal();
    }






</script>


</body>
</html>
