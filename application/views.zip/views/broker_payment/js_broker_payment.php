
<script>


    function addModal(id) {


        $("#broker_name").val(id);
        $("#addModal").modal();
    }
    function deleteModal(id) {
        $("#delete_id").val(id);
        $("#myModalDelete").modal();
    }






</script>


</body>
</html>
