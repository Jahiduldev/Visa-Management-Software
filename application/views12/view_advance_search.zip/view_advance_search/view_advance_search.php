<!--main content start-->
<section id="main-content">
    <section class="wrapper site-min-height">


        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        View All Advance Search
                    </header>
                    <div class="panel-body">
                        <form class="cmxform form-horizontal tasi-form" target="_blank"  role="form" method="post"  action="<?php echo site_url('view_customer/print_page');  ?>">
                            
                        <div class="adv-table">
                            <table id="example" class="display dataTable" role="grid" aria-describedby="example_info" style="width: 100%;" width="100%" cellspacing="0">


                                <thead>
                                    <tr role="row">
                                        <th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 111px;" aria-sort="ascending" >Sl.</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 50px;" >Name</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;" >PASSPORT NO.</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;"  >ID NO.</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;" >VISA NO.</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;" >REFERENCE NAME</th>

                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 50px;" >Broker Name</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;" >Broker Mobile Number</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;"  >Reference Mobile Number</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;" >Sponsor Name</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;" >Gender</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;" >Passport Site</th>
                                        <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 100px;" >Note</th>
                                    </tr>

                                </thead>

                                <tfoot>
                                    <tr>
                                        <th rowspan="1" colspan="1"><input placeholder="Search Sl" type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search Name" type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search PASSPORT NO." type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search ID NO." type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search  VISA NO." type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search REFERENCE NAME" type="text"></th>

                                        <th rowspan="1" colspan="1"><input placeholder="Search Broker Name" type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search Broker Mobile Number" type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search Reference Mobile Number" type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search Sponsor Name" type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search  Gender" type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search Passport Site" type="text"></th>
                                        <th rowspan="1" colspan="1"><input placeholder="Search Note" type="text"></th>
                                    </tr>
                                </tfoot>

                                <tbody>

                                    <?php
                                    foreach($passport_makings_data as $row):
                                        $id= $row->id;
                                        $name= $row->name;
                                        $passport_no= $row->passport_no;
                                        $basic_id_number= $row->basic_id_number;
                                        $basic_visa_number= $row->basic_visa_number;
                                        $reference_name= $row->reference_name;

                                        $broker_name= $row->broker_name;
                                        $broker_mobile_number= $row->broker_mobile_number;
                                        $reference_mobile_number= $row->reference_mobile_number;
                                        $okala_sponsor_name= $row->okala_sponsor_name;
                                        $basic_passport_type= $row->basic_passport_type;
                                        $basic_receive_site= $row->basic_receive_site;
                                        $basic_note= $row->basic_note;
                                        ?>

                                    <tr role="row" class="odd">
                                        <td><input type="checkbox" id="chk<?=$id?>" name="chk<?=$id?>" value="<?=$id?>"></td>
                                        <td><?=$name?></td>
                                        <td><?=$passport_no?></td>
                                        <td><?=$basic_id_number?></td>
                                        <td><?=$basic_visa_number?></td>
                                        <td><?=$reference_name?></td>

                                        <td><?=$broker_name?></td>
                                        <td><?=$broker_mobile_number?></td>
                                        <td><?=$reference_mobile_number?></td>
                                        <td><?=$okala_sponsor_name?></td>
                                        <td><?=$basic_passport_type?></td>
                                        <td><?=$basic_receive_site?></td>
                                        <td><?=$basic_note?></td>

                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
</form>
                    </div>
                </section>
            </div>
        </div>




    </section>
</section>
<!--main content end-->






<!-- modal -->

